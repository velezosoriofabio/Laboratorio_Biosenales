# Análisis de Señales: ECG y EEG
## Funcionamiento para ECG

1. El archivo `signals.mat` en la **misma carpeta**
2. Ejecutar el código **en orden**, bloque por bloque, para realizarlo correctamente.
---

## Funcionamiento para EEG

1. El archivo de los datos con las señales EEG se encuentra en **Google Drive** y tiene un **enlace público**.
2. En el notebook se encuentra una celda con el código necesario para cargar el archivo desde Drive.
3. Ejecutar el código **en orden**, bloque por bloque, para realizarlo correctamente.
